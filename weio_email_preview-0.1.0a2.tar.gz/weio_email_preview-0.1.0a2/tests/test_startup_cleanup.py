"""Startup-failure cleanup tests for email_preview.Chrome (DISTRIBUTION-1017 repair). No real browser is launched:
find_chrome, subprocess.Popen, http_json and websocket.create_connection are mocked. Each test asserts that a failed
start leaves no scratch profile directory behind and that a started process is terminated."""
import os
import sys
import tempfile
import unittest
from unittest import mock

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import email_preview  # noqa: E402


class FakeProc:
    def __init__(self):
        self.terminated = self.killed = False

    def terminate(self):
        self.terminated = True

    def kill(self):
        self.killed = True


class StartupCleanup(unittest.TestCase):
    def setUp(self):
        self.base = tempfile.mkdtemp(prefix="ep-test-")
        self.made = []
        real = tempfile.mkdtemp

        def mkdtemp(prefix=""):
            d = real(prefix=prefix, dir=self.base)
            self.made.append(d)
            return d
        patches = [mock.patch.object(email_preview.tempfile, "mkdtemp", side_effect=mkdtemp),
                   mock.patch.object(email_preview.time, "sleep", lambda s: None)]
        for p in patches:
            p.start()
            self.addCleanup(p.stop)

    def tearDown(self):
        email_preview.shutil.rmtree(self.base, ignore_errors=True)

    def assert_no_profile_left(self):
        self.assertEqual(len(self.made), 1)
        self.assertFalse(os.path.exists(self.made[0]), "scratch profile leaked")

    def test_missing_binary(self):
        with mock.patch.object(email_preview, "find_chrome", side_effect=RuntimeError("no Chrome/Chromium found")):
            with self.assertRaises(RuntimeError):
                email_preview.Chrome()
        self.assert_no_profile_left()

    def test_popen_failure(self):
        with mock.patch.object(email_preview, "find_chrome", return_value="/bin/false"), \
             mock.patch.object(email_preview.subprocess, "Popen", side_effect=OSError("exec failed")):
            with self.assertRaises(OSError):
                email_preview.Chrome()
        self.assert_no_profile_left()

    def test_devtools_timeout(self):
        proc = FakeProc()
        with mock.patch.object(email_preview, "find_chrome", return_value="/bin/false"), \
             mock.patch.object(email_preview.subprocess, "Popen", return_value=proc):
            with self.assertRaises(RuntimeError) as cm:
                email_preview.Chrome()           # DevToolsActivePort never appears
        self.assertIn("did not come up", str(cm.exception))
        self.assertTrue(proc.terminated, "started browser not terminated")
        self.assert_no_profile_left()

    def test_websocket_failure(self):
        proc = FakeProc()

        def popen(argv, **kw):
            prof = [a for a in argv if a.startswith("--user-data-dir=")][0].split("=", 1)[1]
            with open(os.path.join(prof, "DevToolsActivePort"), "w") as fh:
                fh.write("9222\n/devtools/browser/x\n")
            return proc
        with mock.patch.object(email_preview, "find_chrome", return_value="/bin/false"), \
             mock.patch.object(email_preview.subprocess, "Popen", side_effect=popen), \
             mock.patch.object(email_preview, "http_json",
                               return_value=[{"type": "page", "webSocketDebuggerUrl": "ws://127.0.0.1:9222/x"}]), \
             mock.patch.object(email_preview.websocket, "create_connection", side_effect=ConnectionRefusedError("ws")):
            with self.assertRaises(ConnectionRefusedError):
                email_preview.Chrome()
        self.assertTrue(proc.terminated, "started browser not terminated")
        self.assert_no_profile_left()


if __name__ == "__main__":
    unittest.main(verbosity=2)
